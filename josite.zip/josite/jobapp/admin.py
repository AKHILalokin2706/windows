from django.contrib import admin

from .models import JobApplicationModel

admin.site.register(JobApplicationModel)
