# from msilib.schema import ListView
# from django.shortcuts import render
# from django.views import View
# from flask import request
# from .forms import JobApplicationForm

# class job_application_view(View):
#     template_name = 'newuser.html'

#     def get(self, request, *args, **kwargs):
#         form = JobApplicationForm()
#         return render(request, self.template_name, {'form': form})

#     def post(self, request, *args, **kwargs):
#         form = JobApplicationForm(request.POST)
#         if form.is_valid():
           
#             pass
#         return render(request, 'newuser.html', {'form': form})

# class EditView(View):
#      def get(self, request):
#         return render(request, 'edit.html')
# class JobApplicationListView(ListView):
#     model = JobApplicationForm
#     template_name = 'listing.html'
#     context_object_name = 'applications'
from django.contrib import messages
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from . models import JobApplicationModel
from . forms import JobApplicationForm

class JobListView(ListView):
    model = JobApplicationModel
    template_name = 'listing.html'
    context_object_name = 'data'
    ordering = ['-id']

class JobCreateView(CreateView):
    model = JobApplicationModel
    form_class = JobApplicationForm
    template_name = 'newuser.html'
    success_url = reverse_lazy('listing')
    def form_valid(self,form):
      messages.add_message(self.request,messages.INFO, 'Job application submitted successfully!')
      return super().form_valid(form)

class JobUpdateView(UpdateView):
    model = JobApplicationModel
    form_class = JobApplicationForm
    template_name = 'edit.html'
    success_url = reverse_lazy('listing')
    def form_valid(self,form):
      messages.add_message(self.request,messages.INFO, 'Job application edited successfully!')
      return super().form_valid(form)

class JobDeleteView(DeleteView):
    model = JobApplicationModel
    template_name = 'delete.html'  # Create a delete.html template for confirmation
    success_url = reverse_lazy('listing')
