from django.db import models

class JobApplicationModel(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('others', 'Others'),
    ]

    JOB_TYPE_CHOICES = [
        ('','please select an option'),
        ('Software Engineer', 'Software Engineer'),
        ('Teacher', 'Teacher'),
        ('Driver', 'Driver'),
        ('Data Analyst', 'Data Analyst'),
        ('Cloud Engineer', 'Cloud Engineer'),
    ]

    EXPERIENCE_CHOICES = [
        ('','please select an option'),
        ('0-1 years', '0-1 years'),
        ('1-2 years', '1-2 years'),
        ('2-4 years', '2-4 years'),
        ('4-5 years', '4-5 years'),
        ('5+ years', '5+ years'),
    ]

    COUNTRY_CODE_CHOICES = [
        ('+91', '+91'),
        ('+7', '+7'),
        # Add more country codes as needed
    ]

    fullname = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    dob = models.DateField()
    phonenumber = models.CharField(max_length=15)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES,default=None)
    job_type = models.CharField(max_length=50, choices=JOB_TYPE_CHOICES)
    experience_type = models.CharField(max_length=20, choices=EXPERIENCE_CHOICES,default=None)
    address = models.CharField(max_length=100)
    address2 = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    pincode = models.CharField(max_length=10)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50,blank=True, null=True)
    countrycode = models.CharField(max_length=3, choices=COUNTRY_CODE_CHOICES, default='+91', blank=True, null=True)

    def __str__(self):
        return self.fullname 
    